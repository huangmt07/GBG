from difflib import SequenceMatcher, get_close_matches

num_1 = '0911333123'
num_2 = '0912333123'

seq = SequenceMatcher(a=num_1,b=num_2)#a,b 帶入參數
#print(seq.ratio())#相似度比較

word_list = ['0912333123','0930333123','0939333123']
match = get_close_matches(num_1,word_list,n=1,cutoff=0.3)
print(match)


